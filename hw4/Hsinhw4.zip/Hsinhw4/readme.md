**Running method:**  
cd ./server  
node start.js   
addressing localhost:8080/part1/graph.html or localhost:8080/part2/hw4.html on browers.  
